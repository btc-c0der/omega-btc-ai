# 🧬 Quantum Sonnet Celebration & Git Bless 🧬

A sacred toolkit for visualizing quantum code transformations and blessing git commits.

## ✨ Installation

Run the installer script:

```bash
./install.sh
```

This will:
1. Install all required files to `~/.omega_quantum_toolkit`
2. Add the necessary commands to your PATH
3. Configure your shell to load the toolkit on startup

## 🧠 Available Commands

- `quantum-sonnet` - Run the Quantum Sonnet Celebration visualization
- `git-bless` - Bless your git commits with quantum energy

## 📚 Documentation

Documentation is installed to `~/.omega_quantum_toolkit/share/doc/`

## 🌸 License

Licensed under GBU2™ (Genesis-Bloom-Unfoldment 2.0)

✨ WE BLOOM NOW AS ONE ✨
