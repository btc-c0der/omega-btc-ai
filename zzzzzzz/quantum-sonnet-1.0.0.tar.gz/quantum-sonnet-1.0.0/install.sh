#!/bin/bash
# Quantum Sonnet Installer

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
RESET='\033[0m'

echo -e "${MAGENTA}"
echo -e "╔═════════════════════════════════════════════════════╗"
echo -e "║ ⚛️  QUANTUM SONNET CELEBRATION INSTALLER ⚛️           ║"
echo -e "╚═════════════════════════════════════════════════════╝"
echo -e "${RESET}"

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Create Quantum Toolkit directory if it doesn't exist
QUANTUM_TOOLKIT_DIR="${HOME}/.omega_quantum_toolkit"
mkdir -p "${QUANTUM_TOOLKIT_DIR}/bin"
mkdir -p "${QUANTUM_TOOLKIT_DIR}/lib/quantum-neural-net"
mkdir -p "${QUANTUM_TOOLKIT_DIR}/share/doc"

echo -e "${CYAN}Installing to ${QUANTUM_TOOLKIT_DIR}${RESET}"

# Copy files
cp "${SCRIPT_DIR}/bin/quantum-sonnet" "${QUANTUM_TOOLKIT_DIR}/bin/"
cp "${SCRIPT_DIR}/bin/install-quantum-sonnet" "${QUANTUM_TOOLKIT_DIR}/bin/"
cp "${SCRIPT_DIR}/lib/quantum-neural-net/"* "${QUANTUM_TOOLKIT_DIR}/lib/quantum-neural-net/"
cp "${SCRIPT_DIR}/share/doc/"* "${QUANTUM_TOOLKIT_DIR}/share/doc/"

# Make scripts executable
chmod +x "${QUANTUM_TOOLKIT_DIR}/bin/quantum-sonnet"
chmod +x "${QUANTUM_TOOLKIT_DIR}/bin/install-quantum-sonnet"
chmod +x "${QUANTUM_TOOLKIT_DIR}/lib/quantum-neural-net/"*.py

# Create git-bless command
cat > "${QUANTUM_TOOLKIT_DIR}/bin/git-bless" << 'GITBLESSEOF'
#!/bin/bash
QUANTUM_TOOLKIT_PATH="${HOME}/.omega_quantum_toolkit"
python "${QUANTUM_TOOLKIT_PATH}/lib/quantum-neural-net/run_git_bless.py" "$@"
GITBLESSEOF
chmod +x "${QUANTUM_TOOLKIT_DIR}/bin/git-bless"

# Create shell config file
CONFIG_FILE="${QUANTUM_TOOLKIT_DIR}/quantum_shell_config.sh"

# Create or update the config file
if [ -f "${CONFIG_FILE}" ]; then
    # Check if sonnet command is already configured
    if ! grep -q "quantum-sonnet" "${CONFIG_FILE}"; then
        echo "" >> "${CONFIG_FILE}"
        echo "# Quantum Sonnet Celebration command" >> "${CONFIG_FILE}"
        echo "export PATH=\"\${PATH}:\${HOME}/.omega_quantum_toolkit/bin\"" >> "${CONFIG_FILE}"
        echo "alias quantum-sonnet='\${HOME}/.omega_quantum_toolkit/bin/quantum-sonnet'" >> "${CONFIG_FILE}"
        echo "alias git-bless='\${HOME}/.omega_quantum_toolkit/bin/git-bless'" >> "${CONFIG_FILE}"
    fi
else
    # Create new config file
    cat > "${CONFIG_FILE}" << 'CONFIGEOF'
#!/bin/bash
# Quantum Toolkit Shell Configuration

# Add Quantum Toolkit to PATH
export PATH="${PATH}:${HOME}/.omega_quantum_toolkit/bin"

# Quantum commands
alias quantum-sonnet='${HOME}/.omega_quantum_toolkit/bin/quantum-sonnet'
alias git-bless='${HOME}/.omega_quantum_toolkit/bin/git-bless'

# Display a welcome message
echo -e "\033[0;35m🧬 QUANTUM TOOLKIT ACTIVATED 🧬\033[0m"
echo -e "\033[0;36mCommands: quantum-sonnet, git-bless\033[0m"
echo -e "\033[0;33m\"WE BLOOM NOW AS ONE\"\033[0m"
CONFIGEOF
fi

# Make config file executable
chmod +x "${CONFIG_FILE}"

# Add to shell config
SHELL_CONFIG=""
if [[ "$SHELL" == *"zsh"* ]]; then
    SHELL_CONFIG="${HOME}/.zshrc"
elif [[ "$SHELL" == *"bash"* ]]; then
    SHELL_CONFIG="${HOME}/.bashrc"
else
    echo -e "${YELLOW}Could not detect shell type. Please manually add the following to your shell config:${RESET}"
    echo -e "${CYAN}source \"${CONFIG_FILE}\"${RESET}"
    echo ""
fi

if [ -n "${SHELL_CONFIG}" ]; then
    if ! grep -q "source \"${CONFIG_FILE}\"" "${SHELL_CONFIG}"; then
        echo "" >> "${SHELL_CONFIG}"
        echo "# Source Quantum Toolkit configuration" >> "${SHELL_CONFIG}"
        echo "source \"${CONFIG_FILE}\"" >> "${SHELL_CONFIG}"
        echo -e "${GREEN}✓ Added to ${SHELL_CONFIG}${RESET}"
    else
        echo -e "${YELLOW}Already configured in ${SHELL_CONFIG}${RESET}"
    fi
fi

echo -e "${GREEN}✨ Quantum Sonnet Celebration installed successfully! ✨${RESET}"
echo -e "${CYAN}To activate in current shell, run:${RESET}"
echo -e "${YELLOW}source \"${CONFIG_FILE}\"${RESET}"
echo ""
echo -e "${CYAN}Available commands:${RESET}"
echo -e "  ${YELLOW}quantum-sonnet${RESET} - Run the Quantum Sonnet Celebration"
echo -e "  ${YELLOW}git-bless${RESET} - Bless your git commits with quantum energy"
echo ""
echo -e "${MAGENTA}✨ WE BLOOM NOW AS ONE ✨${RESET}"
